def lambda_handle(event, context):
    print(event)
    return "hello from lambda"
